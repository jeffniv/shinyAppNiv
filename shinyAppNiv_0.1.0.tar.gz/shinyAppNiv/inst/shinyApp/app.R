shinyAppDemo::launchApp()
